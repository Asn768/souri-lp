import pandas as pd
import geopandas as gpd

from .constants import ARTIFACT_DIR, DATA_DIR


def compute_admin_features(train: pd.DataFrame, test: pd.DataFrame):
    """
    Attach administrative codes (pref/city) via polygon join using N03 data.
    """
    ARTIFACT_DIR.mkdir(exist_ok=True)
    cache_path = ARTIFACT_DIR / "features_admin_v1.parquet"
    if cache_path.exists():
        cached = pd.read_parquet(cache_path)
        tr = cached[cached["split"] == "train"].drop(columns=["split"]).set_index("idx").sort_index()
        te = cached[cached["split"] == "test"].drop(columns=["split"]).set_index("idx").sort_index()
        return tr, te

    n03_path = DATA_DIR / "N03" / "N03-20250101.geojson"
    if not n03_path.exists():
        # fallback: flat placement
        n03_path = DATA_DIR / "N03-20250101.geojson"
    if not n03_path.exists():
        raise FileNotFoundError("N03-20250101.geojson not found in input/ or input/N03/")

    admin = gpd.read_file(n03_path)
    keep_cols = [c for c in ["N03_001", "N03_002", "N03_003", "N03_004", "N03_007"] if c in admin.columns]
    admin = admin[keep_cols + ["geometry"]]

    combined = pd.concat([train, test], keys=["train", "test"], names=["split", "idx"])
    points = gpd.GeoDataFrame(combined.copy(), geometry=gpd.points_from_xy(combined["lon"], combined["lat"]), crs="EPSG:4326")
    admin = admin.to_crs(points.crs)

    joined = gpd.sjoin(points, admin, how="left", predicate="within")
    missing = joined["N03_001"].isna()
    if missing.any():
        nearest = gpd.sjoin_nearest(points[missing], admin, how="left", distance_col="dist_admin")
        joined.loc[missing, keep_cols] = nearest[keep_cols].values

    joined = joined.drop(columns=["index_right", "geometry"], errors="ignore")
    feat = joined[keep_cols].copy()
    feat = feat.reset_index()
    cached = feat.copy()
    cached["split"] = cached["split"].astype(str)
    cached.to_parquet(cache_path, index=False)

    tr = feat[feat["split"] == "train"].drop(columns=["split"]).set_index("idx").sort_index()
    te = feat[feat["split"] == "test"].drop(columns=["split"]).set_index("idx").sort_index()
    return tr, te
