# Marks src as a package for relative imports.
