import numpy as np


def safe_div(a, b):
    return np.where(b != 0, a / b, np.nan)


def mape(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / np.clip(np.abs(y_true), 1e-6, None))) * 100
