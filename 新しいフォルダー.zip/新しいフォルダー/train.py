import argparse
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

# Support running as a script (python src/train.py) and as a module (python -m src.train)
if __package__ is None:
    import sys

    sys.path.append(str(Path(__file__).resolve().parent.parent))
    __package__ = "src"

from .constants import ID_COL, OUTPUT_DIR, TARGET
from .data import _cv_target_encode_mean, add_area_bin_target_encoding, load_data, preprocess
from .features_admin import compute_admin_features
from .features_geo import compute_geo_features, compute_land_temporal_features, compute_n05_features
from .model import cv_train, save_logs, save_plots, train_full


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-log-target", action="store_true", help="Disable log1p on unit-price target")
    parser.add_argument(
        "--lgb-profile",
        type=str,
        default="base",
        choices=[
            "base",
            "fast_huber",
            "fast",
            "reg_strong",
            "huber_n3000",
            "huber_n4000",
            "huber_n5000",
            "huber_n8000",
            "huber_n15000",
            "huber_n20000",
            "huber_n50000",
            "huber_lr025_n2500",
        ],
        help="LightGBM parameter preset (featuresは不変でパラメータのみ変更)",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed for CV split and LightGBM")
    return parser.parse_args()


def get_lgb_profile(name: str):
    """
    Return (params, eval_metric) tuple for LightGBM preset.
    """
    eval_metric = "l1"
    params = {}
    if name == "reg_strong":
        params = {
            "num_leaves": 95,
            "max_depth": 7,
            "min_child_samples": 80,
            "lambda_l1": 0.1,
            "lambda_l2": 1.0,
            "subsample": 0.8,
            "colsample_bytree": 0.9,
        }
    elif name == "fast_huber":
        params = {
            "learning_rate": 0.08,
            "n_estimators": 400,
            "objective": "huber",
            "alpha": 0.9,
        }
    elif name == "huber_n3000":
        params = {"learning_rate": 0.03, "n_estimators": 3000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n4000":
        params = {"learning_rate": 0.03, "n_estimators": 4000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n5000":
        params = {"learning_rate": 0.03, "n_estimators": 5000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n8000":
        params = {"learning_rate": 0.03, "n_estimators": 8000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n15000":
        params = {"learning_rate": 0.03, "n_estimators": 15000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n20000":
        params = {"learning_rate": 0.03, "n_estimators": 20000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_n50000":
        params = {"learning_rate": 0.03, "n_estimators": 50000, "objective": "huber", "alpha": 0.9}
    elif name == "huber_lr025_n2500":
        params = {"learning_rate": 0.025, "n_estimators": 2500, "objective": "huber", "alpha": 0.9}
    elif name == "fast":
        params = {"learning_rate": 0.08, "n_estimators": 400}
    return params, eval_metric


def main():
    args = parse_args()
    run_tag = "geo_knn_v1"
    run_name = datetime.now().strftime(f"%Y%m%d_%H%M%S_{run_tag}")
    train, test = load_data()
    train_df, test_df, y, cat_cols = preprocess(train, test)

    use_unit_price = True
    use_log_target = not args.no_log_target
    house_area_min = 10.0
    house_area_max = train_df["house_area"].quantile(0.995)
    price_multiplier_train = np.clip(
        train_df["house_area"].fillna(train_df["house_area"].median()).to_numpy(), house_area_min, house_area_max
    )
    price_multiplier_test = np.clip(
        test_df["house_area"].fillna(train_df["house_area"].median()).to_numpy(), house_area_min, house_area_max
    )
    if use_unit_price:
        y_unit = y / price_multiplier_train
        y_for_training = np.log1p(y_unit) if use_log_target else y_unit
        y_for_eval_price = y
    else:
        y_for_training = y
        y_for_eval_price = None

    train_df, test_df = add_area_bin_target_encoding(train_df, test_df, y_for_training, n_bins=6)
    cat_cols = cat_cols + ["house_area_bin"]

    geo_train, geo_test = compute_geo_features(train_df, test_df)
    train_df = pd.concat([train_df, geo_train], axis=1)
    test_df = pd.concat([test_df, geo_test], axis=1)
    new_cat_cols = [c for c in ["geo_near_use", "geo_near_city_plan", "geo_near_structure"] if c in train_df.columns]
    for c in new_cat_cols:
        train_df[c] = train_df[c].astype("category")
        test_df[c] = test_df[c].astype("category")
    cat_cols = cat_cols + new_cat_cols

    geo_freq_cols = [c for c in ["geo_near_use", "geo_near_city_plan", "geo_near_structure"] if c in train_df.columns]
    for c in geo_freq_cols:
        freq = train_df[c].value_counts(normalize=True)
        train_df[f"{c}_freq"] = train_df[c].map(freq).fillna(0)
        test_df[f"{c}_freq"] = test_df[c].map(freq).fillna(0)
        train_df = train_df.drop(columns=[c])
        test_df = test_df.drop(columns=[c])
    cat_cols = [c for c in cat_cols if c in train_df.columns]

    geo_price_cols = [col for col in train_df.columns if col.startswith("geo_knn_mean_") or col.startswith("geo_knn_median_")]
    if "geo_near_price" in train_df.columns:
        geo_price_cols.append("geo_near_price")
    for col in geo_price_cols:
        train_df[f"{col}_log1p"] = np.log1p(train_df[col].clip(lower=0))
        test_df[f"{col}_log1p"] = np.log1p(test_df[col].clip(lower=0))

    # N05: station proximity features
    # N05: station proximity features (lightweight: freqなし)
    n05_tr, n05_te = compute_n05_features(train_df, test_df, radii_km=(0.5, 1.0), include_freq=False)
    train_df = pd.concat([train_df, n05_tr], axis=1)
    test_df = pd.concat([test_df, n05_te], axis=1)

    land_tr, land_te = compute_land_temporal_features(train_df, test_df)
    train_df = pd.concat([train_df, land_tr], axis=1)
    test_df = pd.concat([test_df, land_te], axis=1)

    land_price_cols = [c for c in train_df.columns if c.startswith("land_") and ("price" in c or "dist" in c)]
    for col in land_price_cols:
        if "price" in col:
            train_df[f"{col}_log1p"] = np.log1p(train_df[col].clip(lower=0))
            test_df[f"{col}_log1p"] = np.log1p(test_df[col].clip(lower=0))

    admin_tr, admin_te = compute_admin_features(train_df, test_df)
    train_df = pd.concat([train_df, admin_tr], axis=1)
    test_df = pd.concat([test_df, admin_te], axis=1)
    admin_cat = [c for c in ["N03_001", "N03_002", "N03_003", "N03_004", "N03_007"] if c in train_df.columns]
    for c in admin_cat:
        train_df[c] = train_df[c].astype("category")
        test_df[c] = test_df[c].astype("category")
    cat_cols = cat_cols + admin_cat

    te_admin_cols = [c for c in admin_cat if c in train_df.columns]
    if te_admin_cols:
        target_for_te = y_for_training
        global_mean_te = target_for_te.mean()
        smoothing_map = {"N03_001": 30.0, "N03_002": 20.0, "N03_003": 15.0, "N03_004": 10.0, "N03_007": 10.0}
        default_smoothing = 20.0
        for col in te_admin_cols:
            smooth_k = smoothing_map.get(col, default_smoothing)
            te_mean_cv, te_mean_full = _cv_target_encode_mean(train_df, target_for_te, col, n_splits=5, smoothing=smooth_k, seed=456)
            train_df[f"{col}_te_mean"] = te_mean_cv
            te_series = test_df[col].astype("object")
            test_df[f"{col}_te_mean"] = te_series.map(te_mean_full).astype(float).fillna(global_mean_te)

    lgb_params, eval_metric = get_lgb_profile(args.lgb_profile)
    models, oof, cv_mape, best_iter = cv_train(
        train_df,
        y_for_training,
        cat_cols,
        seed=args.seed,
        price_multiplier=price_multiplier_train if use_unit_price else None,
        y_price=y_for_eval_price,
        sample_weight=None,
        log_target=use_log_target,
        lgb_params=lgb_params,
        eval_metric=eval_metric,
    )
    save_plots(run_name, y if not use_unit_price else y_for_eval_price, oof, train_df, models)
    save_logs(run_name, cv_mape, best_iter, feature_set=run_tag)

    full_model = train_full(train_df, y_for_training, cat_cols, n_estimators=best_iter, lgb_params=lgb_params)
    test_pred = full_model.predict(test_df)
    if use_log_target:
        test_pred = np.expm1(test_pred)
    if use_unit_price:
        test_pred = test_pred * price_multiplier_test
    test_pred = np.clip(test_pred, 0, None)

    OUTPUT_DIR.mkdir(exist_ok=True)
    submit_path = OUTPUT_DIR / f"submit_{run_name}.csv"
    sub_df = pd.DataFrame({ID_COL: test["id"], TARGET: test_pred})
    sub_df.to_csv(submit_path, index=False, header=False)
    print(f"Saved submission to {submit_path}")
    print(f"CV MAPE: {cv_mape:.4f}, best_iter: {best_iter:.1f}")


if __name__ == "__main__":
    main()
