from typing import List, Tuple

import os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from .constants import DATA_DIR, TARGET, ID_COL
from .utils import safe_div

DROP_TEXT_COLS = [
    "building_name",
    "building_name_ruby",
    "homes_building_name",
    "homes_building_name_ruby",
    "full_address",
    "name_ruby",
    # Not used in FI; drop up front to reduce columns
    "reform_place",
    "reform_common_area",
    "reform_exterior_other",
    "reform_etc",
]

DATE_COLS = [
    "building_create_date",
    "building_modify_date",
    "reform_exterior_date",
    "reform_common_area_date",
    "reform_date",
    "reform_wet_area_date",
    "reform_interior_date",
    "snapshot_create_date",
    "new_date",
    "snapshot_modify_date",
    "timelimit_date",
    "usable_date",
    "renovation_date",
]

# numericだがカテゴリとして扱う列（コード/離散ID/小さな整数）
FORCE_CAT_NUM_COLS = {
    "building_status",
    "bukken_type",
    "traffic_car",
    "flg_new",
    "parking_keiyaku",
    "land_area_kind",
    "land_setback_flg",
    "building_area_kind",
    "management_association_flg",
    "flg_investment",
    "money_kyoueki_tax",
    "usable_status",
    "management_form",
    "parking_money_tax",
    "land_toshi",
    "house_kanrinin",
    "parking_kubun",
    "genkyo_code",
    "land_chisei",
    "land_road_cond",
    "building_land_chimoku",
    "dwelling_unit_window_angle",
    "snapshot_window_angle",
    "madori_kind_all",
    "building_structure",
    "land_youto",
    "building_type",
    "addr1_1",
    "addr1_2",
    "floor_plan_code",
}

# high-cardカテゴリでfreqのみ残す対象
FREQ_ONLY_COLS = {
    "statuses",
    "unit_tag_id",
    "building_tag_id",
    "unit_name",
    "addr2_name",
    "addr3_name",
    "eki_name1",
    "eki_name2",
    "eki_name3",
    "empty_contents",
    "school_ele_name",
    "school_jun_name",
    "est_other_name",
}

# Special handling: expand top coverage for key columns (keep category + freq)
COMPRESS_SPECIAL = {}


def _smooth_mean(sum_series: pd.Series, count_series: pd.Series, global_mean: float, k: float = 20.0) -> pd.Series:
    """Compute smoothed means for target encoding."""
    return (sum_series + k * global_mean) / (count_series + k)


def _cv_target_encode_mean(df: pd.DataFrame, target: pd.Series, col: str, n_splits: int = 5, smoothing: float = 20.0, seed: int = 123) -> Tuple[pd.Series, pd.Series]:
    """Cross-validated smoothed mean target encoding."""
    from sklearn.model_selection import KFold

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
    te_mean = pd.Series(np.nan, index=df.index, dtype=float)
    global_sum = target.sum()
    global_count = len(target)
    global_mean = global_sum / global_count

    for tr_idx, va_idx in kf.split(df):
        tr_series = df.iloc[tr_idx][col]
        va_series = df.iloc[va_idx][col]
        stats = target.iloc[tr_idx].groupby(tr_series, observed=False).agg(["sum", "count"])
        smoothed = _smooth_mean(stats["sum"], stats["count"], global_mean, k=smoothing)
        values = va_series.map(smoothed).astype(float).to_numpy()
        te_mean.iloc[va_idx] = values

    te_mean = te_mean.fillna(global_mean)

    # full-data stats for test
    stats_full = target.groupby(df[col], observed=False).agg(["sum", "count"])
    smoothed_full = _smooth_mean(stats_full["sum"], stats_full["count"], global_mean, k=smoothing)
    return te_mean, smoothed_full


def load_data():
    train = pd.read_csv(DATA_DIR / "train.csv", low_memory=False)
    test = pd.read_csv(DATA_DIR / "test.csv", low_memory=False)
    return train, test


def preprocess(train: pd.DataFrame, test: pd.DataFrame):
    train = train.copy()
    test = test.copy()
    add_train: dict = {}
    add_test: dict = {}

    # Remove obvious high-cardinality text columns that are likely noisy
    drop_cols = [c for c in DROP_TEXT_COLS if c in train.columns]
    if drop_cols:
        train = train.drop(columns=drop_cols)
        test = test.drop(columns=drop_cols)

    # target_ym -> year/month
    for df in (train, test):
        df["target_year"] = (df["target_ym"] // 100).astype(int)
        df["target_month"] = (df["target_ym"] % 100).astype(int)

    # building age (year-level; year_built is yyyymm so take //100)
    for df in (train, test):
        build_year = (df["year_built"] // 100).astype(float)
        df["building_age"] = df["target_year"] - build_year
        # clamp unrealistically small/large ages to stabilize single-unit price
        df["building_age"] = df["building_age"].clip(lower=0, upper=80)

    # Parse date columns to year/month numeric features
    for col in DATE_COLS:
        if col not in train.columns:
            continue
        for df in (train, test):
            dt = pd.to_datetime(df[col], errors="coerce")
            df[f"{col}_year"] = dt.dt.year
            df[f"{col}_month"] = dt.dt.month
        train = train.drop(columns=[col])
        test = test.drop(columns=[col])

    # Drop low-importance / unused derived columns to speed training
    drop_low_importance = [
        "usable_date_year",
        "usable_date_month",
        "money_shuuzenkikin",
        "money_shuuzenkikin_log1p",
        "money_shuuzenkikin_per_area",
        "money_sonota3",
        "money_sonota3_log1p",
        "money_sonota_str3",
        "reform_interior_date_year",
        "reform_interior_date_month",
        "reform_wet_area_date_year",
        "reform_wet_area_date_month",
        "reform_date_year",
        "reform_date_month",
        "building_age_bin",
        "traffic_car",
        # distance isnull flags with low FI
        "est_other_distance_isnull",
        "school_ele_distance_isnull",
        "shopping_street_distance_isnull",
        "school_jun_distance_isnull",
    ]
    drop_low_importance = [c for c in drop_low_importance if c in train.columns]
    if drop_low_importance:
        train = train.drop(columns=drop_low_importance)
        test = test.drop(columns=drop_low_importance)

    # Separate target
    y = train[TARGET]
    train = train.drop(columns=[TARGET])

    # Align columns
    common_cols = train.columns
    test = test[common_cols]

    # Drop fully-missing columns (info-less)
    full_missing = [c for c in train.columns if train[c].isna().all()]
    if full_missing:
        train = train.drop(columns=full_missing)
        test = test.drop(columns=full_missing)

    # Missing flags for columns with high missingness (selective)
    miss_rate = train.isna().mean()
    flag_cols = [c for c, r in miss_rate.items() if (0.3 < r < 0.999)]
    add_train = {}
    add_test = {}
    for col in flag_cols:
        add_train[f"{col}_isnull"] = train[col].isna().astype(np.int8)
        add_test[f"{col}_isnull"] = test[col].isna().astype(np.int8)

    # Identify categorical columns (consider both train/test dtypes + forced list)
    cat_cols = [
        c
        for c in train.columns
        if (train[c].dtype == "object")
        or (test[c].dtype == "object")
        or (c in FORCE_CAT_NUM_COLS)
    ]

    # Compress high-card categories and add frequency encodings (selective)
    def compress_and_freq(df_tr, df_te, col, coverage=0.75, max_top=15):
        params = COMPRESS_SPECIAL.get(col, {"coverage": coverage, "max_top": max_top})
        coverage = params["coverage"]
        max_top = params["max_top"]
        tr_series = df_tr[col].fillna("missing")
        te_series = df_te[col].fillna("missing")
        vc = tr_series.value_counts(normalize=True)
        if len(vc) <= 30:
            df_tr[col] = tr_series
            df_te[col] = te_series
            return
        cumsum = vc.cumsum()
        top = list(cumsum[cumsum <= coverage].index)
        top = (vc.head(max_top).index.union(top)).tolist()

        def mapper(s):
            s = s.fillna("missing")
            return s.where(s.isin(top), other="other")

        comp_tr = mapper(tr_series)
        comp_te = mapper(te_series)

        freq = comp_tr.value_counts(normalize=True)
        add_train[f"{col}_freq"] = comp_tr.map(freq).fillna(0)
        add_test[f"{col}_freq"] = comp_te.map(freq).fillna(0)

        if col in FREQ_ONLY_COLS:
            df_tr.drop(columns=[col], inplace=True)
            df_te.drop(columns=[col], inplace=True)
        else:
            df_tr[col] = comp_tr
            df_te[col] = comp_te

    for col in cat_cols:
        compress_and_freq(train, test, col)

    # Building tag features (controlled by env BUILDING_TAG_MODE: count_only / flags_only / both / off)
    tag_mode = os.getenv("BUILDING_TAG_MODE", "both").lower()
    tag_col = "building_tag_id"
    BUILDING_TAG_TOP = [
        "210101",
        "210201",
        "210301",
        "210401",
        "310101",
        "310201",
        "320101",
        "320901",
        "321001",
        "321101",
        "330201",
        "330301",
        "333601",
        "334101",
        "220301",
    ]
    use_count = tag_mode in {"count_only", "both"}
    use_flags = tag_mode in {"flags_only", "both"}
    if tag_col in train.columns and (use_count or use_flags):
        for df, add_dict in [(train, add_train), (test, add_test)]:
            tags_split = df[tag_col].fillna("").astype(str).str.split("/")
            if use_count:
                tag_count = tags_split.apply(lambda x: sum(bool(t) for t in x))
                add_dict["building_tag_count"] = tag_count.astype(int)
            if use_flags:
                for tag in BUILDING_TAG_TOP:
                    add_dict[f"building_tag_has_{tag}"] = tags_split.apply(lambda x: int(tag in x))

    # Recompute categorical columns after compression (include forced)
    cat_cols = [
        c
        for c in train.columns
        if (train[c].dtype == "object")
        or (test[c].dtype == "object")
        or (c in FORCE_CAT_NUM_COLS)
    ]

    # Fill missing: category -> "missing", numeric -> median
    for col in train.columns:
        if col in cat_cols:
            train[col] = train[col].fillna("missing")
            test[col] = test[col].fillna("missing")
        else:
            med = train[col].median()
            train[col] = train[col].fillna(med)
            test[col] = test[col].fillna(med)

    # Clip numeric outliers and add log1p variants for selective non-negative, skewed columns
    num_cols = [c for c in train.columns if c not in cat_cols and train[c].dtype != "category"]
    exclude_substrings = ["lat", "lon", "code", "id", "ym", "year", "month", "geo_knn", "dist"]
    longtail_cols: List[str] = []
    for col in num_cols:
        name = col.lower()
        if any(x in name for x in exclude_substrings):
            continue
        if train[col].min() < 0:
            continue
        skew = train[col].skew(skipna=True)
        if skew is not None and skew > 1.5:
            longtail_cols.append(col)

    for col in longtail_cols:
        q_low, q_high = train[col].quantile([0.005, 0.995])
        train[col] = train[col].clip(q_low, q_high)
        test[col] = test[col].clip(q_low, q_high)
        add_train[f"{col}_log1p"] = np.log1p(train[col])
        add_test[f"{col}_log1p"] = np.log1p(test[col])

    # Clip distance-related columns with fixed upper bounds (meters)
    dist_clip_map = {
        "bank_distance": 4000,
        "convenience_distance": 4000,
        "drugstore_distance": 4000,
        "est_other_distance": 4000,
        "hospital_distance": 4000,
        "park_distance": 4000,
        "super_distance": 4000,
        "shopping_street_distance": 4000,
        "school_ele_distance": 4000,
        "school_jun_distance": 4000,
        "parking_distance": 100,
        "walk_distance1": 8000,
        "walk_distance2": 6000,
    }
    for col, upper in dist_clip_map.items():
        if col in train.columns:
            train[col] = train[col].clip(lower=0, upper=upper)
            test[col] = test[col].clip(lower=0, upper=upper)

    # Clip area-related extreme outliers
    area_clip_map = {
        "building_area": 10000,
        "total_floor_area": 500,
        "building_land_area": 2500,
        "land_area_all": 2500,
        "snapshot_land_area": 2000,
        "area_per_room": 120000,
        "balcony_area": 35,
        "house_area": 300,
        "unit_area": 300,
    }
    for col, upper in area_clip_map.items():
        if col in train.columns:
            train[col] = train[col].clip(lower=0, upper=upper)
            test[col] = test[col].clip(lower=0, upper=upper)

    # Geo-encoding: sin/cos lat/lon and small KMeans clusters (use add_* then concat)
    lat_rad_tr = np.radians(train["lat"])
    lon_rad_tr = np.radians(train["lon"])
    lat_rad_te = np.radians(test["lat"])
    lon_rad_te = np.radians(test["lon"])
    add_train.update(
        {
            "lat_rad": lat_rad_tr,
            "lon_rad": lon_rad_tr,
            "lat_sin": np.sin(lat_rad_tr),
            "lat_cos": np.cos(lat_rad_tr),
            "lon_sin": np.sin(lon_rad_tr),
            "lon_cos": np.cos(lon_rad_tr),
        }
    )
    add_test.update(
        {
            "lat_rad": lat_rad_te,
            "lon_rad": lon_rad_te,
            "lat_sin": np.sin(lat_rad_te),
            "lat_cos": np.cos(lat_rad_te),
            "lon_sin": np.sin(lon_rad_te),
            "lon_cos": np.cos(lon_rad_te),
        }
    )

    coords = train[["lat", "lon"]].to_numpy()
    kmeans = KMeans(n_clusters=10, random_state=42, n_init=5)
    add_train["geo_cluster10"] = kmeans.fit_predict(coords)
    add_test["geo_cluster10"] = kmeans.predict(test[["lat", "lon"]].to_numpy())

    # Simple ratios
    add_train["floor_ratio"] = safe_div(train["room_floor"], train["floor_count"])
    add_test["floor_ratio"] = safe_div(test["room_floor"], test["floor_count"])

    add_train["area_per_room"] = safe_div(train["total_floor_area"], np.maximum(train["room_count"], 1))
    add_test["area_per_room"] = safe_div(test["total_floor_area"], np.maximum(test["room_count"], 1))

    add_train["balcony_ratio"] = safe_div(train.get("balcony_area", np.nan), train["total_floor_area"])
    add_test["balcony_ratio"] = safe_div(test.get("balcony_area", np.nan), test["total_floor_area"])

    # Unit-price aware: monetary columns per house_area
    per_area_cols = ["money_kyoueki", "money_shuuzen", "money_shuuzenkikin", "parking_money"]
    house_area_tr = np.maximum(train["house_area"], 1)
    house_area_te = np.maximum(test["house_area"], 1)
    for col in per_area_cols:
        if col not in train.columns:
            continue
        add_train[f"{col}_per_area"] = safe_div(train[col], house_area_tr)
        add_test[f"{col}_per_area"] = safe_div(test[col], house_area_te)

    # Age bins (helper categories)
    age_bins = [-np.inf, 0, 5, 10, 20, 30, np.inf]
    age_labels = ["age_le0", "age_0_5", "age_5_10", "age_10_20", "age_20_30", "age_ge30"]
    add_train["building_age_bin"] = pd.cut(train["building_age"], bins=age_bins, labels=age_labels)
    add_test["building_age_bin"] = pd.cut(test["building_age"], bins=age_bins, labels=age_labels)

    # Min travel time (bus/eki)
    time_cols = [c for c in ["bus_time1", "bus_time2", "eki_time1", "eki_time2", "eki_time3"] if c in train.columns]
    if time_cols:
        add_train["min_travel_time"] = train[time_cols].min(axis=1)
        add_test["min_travel_time"] = test[time_cols].min(axis=1)

    # Grid target encoding (CV-safe)
    grid_size = 0.01
    grid_id = (np.floor(train["lat"] / grid_size)).astype(int).astype(str) + "_" + (np.floor(train["lon"] / grid_size)).astype(int).astype(str)
    grid_id_test = (np.floor(test["lat"] / grid_size)).astype(int).astype(str) + "_" + (np.floor(test["lon"] / grid_size)).astype(int).astype(str)
    from sklearn.model_selection import KFold

    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    grid_mean = pd.Series(np.nan, index=train.index)
    grid_med = pd.Series(np.nan, index=train.index)
    global_mean = y.mean()
    global_med = y.median()
    for tr_idx, va_idx in kf.split(train):
        g_tr = grid_id.iloc[tr_idx]
        g_va = grid_id.iloc[va_idx]
        y_tr = y.iloc[tr_idx]
        stats = y_tr.groupby(g_tr).agg(["mean", "median"])
        grid_mean.iloc[va_idx] = g_va.map(stats["mean"])
        grid_med.iloc[va_idx] = g_va.map(stats["median"])
    grid_mean = grid_mean.fillna(global_mean)
    grid_med = grid_med.fillna(global_med)
    test_stats = y.groupby(grid_id).agg(["mean", "median"])
    test_mean = grid_id_test.map(test_stats["mean"]).fillna(global_mean)
    test_med = grid_id_test.map(test_stats["median"]).fillna(global_med)
    add_train["grid_mean_cv"] = grid_mean
    add_train["grid_median_cv"] = grid_med
    add_test["grid_mean_cv"] = test_mean
    add_test["grid_median_cv"] = test_med

    # Category-based target encoding (CV-safe) for location/structure codes
    te_cols: List[str] = [c for c in ["addr1_1", "addr1_2", "building_structure", "bukken_type", "floor_plan_code"] if c in train.columns]
    if te_cols:
        for col in te_cols:
            te_mean_cv, te_mean_full = _cv_target_encode_mean(train, y, col, n_splits=5, smoothing=20.0, seed=123)
            add_train[f"{col}_te_mean_cv"] = te_mean_cv
            add_test[f"{col}_te_mean_cv"] = test[col].astype("object").map(te_mean_full).astype(float).fillna(y.mean())

            # Median (unsmoothed) to keep diversity
            te_med = pd.Series(np.nan, index=train.index)
            for tr_idx, va_idx in KFold(n_splits=5, shuffle=True, random_state=124).split(train):
                stats = y.iloc[tr_idx].groupby(train.iloc[tr_idx][col]).median()
                te_med.iloc[va_idx] = train.iloc[va_idx][col].map(stats)
            te_med = te_med.fillna(y.median())
            test_stats = y.groupby(train[col]).median()
            te_med_test = test[col].map(test_stats).fillna(y.median())
            add_train[f"{col}_te_median_cv"] = te_med
            add_test[f"{col}_te_median_cv"] = te_med_test

    # Attach added columns at once to avoid fragmentation
    if add_train:
        train = pd.concat([train, pd.DataFrame(add_train, index=train.index)], axis=1)
        test = pd.concat([test, pd.DataFrame(add_test, index=test.index)], axis=1)

    # Convert object/forced to category for LightGBM
    cat_cols = [
        c
        for c in train.columns
        if (train[c].dtype == "object")
        or (test[c].dtype == "object")
        or (c in FORCE_CAT_NUM_COLS)
    ]
    for col in cat_cols:
        train[col] = train[col].astype("category")
        test[col] = test[col].astype("category")

    return train, test, y, cat_cols


def add_area_bin_target_encoding(train_df: pd.DataFrame, test_df: pd.DataFrame, target_unit: pd.Series, n_bins: int = 6) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Unit-price視点: house_areaを量子化し、単価(target_unit)で5foldターゲットエンコ。
    """
    area_tr = train_df["house_area"].fillna(train_df["house_area"].median())
    area_te = test_df["house_area"].fillna(train_df["house_area"].median())

    # bin edges from train quantiles
    _, bin_edges = pd.qcut(area_tr, q=n_bins, retbins=True, duplicates="drop")
    tr_bin = pd.cut(area_tr, bins=bin_edges, include_lowest=True, labels=False)
    te_bin = pd.cut(area_te, bins=bin_edges, include_lowest=True, labels=False)

    from sklearn.model_selection import KFold

    kf = KFold(n_splits=5, shuffle=True, random_state=321)
    te_mean = pd.Series(np.nan, index=train_df.index)
    te_med = pd.Series(np.nan, index=train_df.index)
    global_mean = target_unit.mean()
    global_med = target_unit.median()

    for tr_idx, va_idx in kf.split(train_df):
        stats = target_unit.iloc[tr_idx].groupby(tr_bin.iloc[tr_idx]).agg(["mean", "median"])
        te_mean.iloc[va_idx] = tr_bin.iloc[va_idx].map(stats["mean"])
        te_med.iloc[va_idx] = tr_bin.iloc[va_idx].map(stats["median"])

    te_mean = te_mean.fillna(global_mean)
    te_med = te_med.fillna(global_med)

    full_stats = target_unit.groupby(tr_bin).agg(["mean", "median"])
    te_mean_test = te_bin.map(full_stats["mean"]).fillna(global_mean)
    te_med_test = te_bin.map(full_stats["median"]).fillna(global_med)

    train_df = train_df.copy()
    test_df = test_df.copy()
    train_df["house_area_bin_te_mean_cv"] = te_mean
    train_df["house_area_bin_te_median_cv"] = te_med
    test_df["house_area_bin_te_mean_cv"] = te_mean_test
    test_df["house_area_bin_te_median_cv"] = te_med_test

    # keep bin id as categorical code (will append to cat_cols in main)
    train_df["house_area_bin"] = tr_bin.astype("Int64")
    test_df["house_area_bin"] = te_bin.astype("Int64")

    return train_df, test_df
