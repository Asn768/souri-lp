from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
from sklearn.neighbors import BallTree

from .constants import ARTIFACT_DIR, DATA_DIR
from .utils import safe_div


def _list_land_files(prefix: str) -> List[Tuple[int, str]]:
    base_dir = DATA_DIR / prefix
    files = []
    if base_dir.exists():
        files += list(base_dir.glob("*.geojson"))
    files += list(DATA_DIR.glob(f"{prefix}-*.geojson")) + list(DATA_DIR.glob(f"{prefix}_*.geojson"))
    items = []
    for p in files:
        stem = p.stem  # e.g., L01-18 or L02_21
        year_part = stem.split("-")[-1].split("_")[-1]
        try:
            year = int(year_part)
        except ValueError:
            continue
        items.append((year, p))
    items.sort(key=lambda x: x[0])
    return items


def _load_land_points(prefix: str) -> pd.DataFrame:
    """
    Load all years for prefix (L01/L02), keeping only year, price, lat, lon.
    Price: main column _006. If missing/zero, backfill from the last non-zero of history cols.
    """
    import geopandas as gpd  # noqa: WPS433

    files = _list_land_files(prefix)
    if not files:
        raise FileNotFoundError(f"No land price geojson files found for {prefix}")

    if prefix == "L01":
        hist_cols = [f"L01_{i:03d}" for i in range(68, 82)]
        attr_cols = {
            "L01_025": "use",
            "L01_027": "structure",
            "L01_032": "floor_above",
            "L01_033": "floor_below",
            "L01_049": "city_plan",
            "L01_052": "bcr",
            "L01_053": "fsr",
            "L01_024": "land_area",
        }
    else:
        hist_cols = [f"L02_{i:03d}" for i in range(69, 83)]
        attr_cols = {
            "L02_024": "use",
            "L02_028": "structure",
            "L02_035": "floor_above",
            "L02_036": "floor_below",
            "L02_048": "city_plan",
            "L02_050": "bcr",
            "L02_051": "fsr",
            "L02_023": "land_area",
        }

    all_df = []
    for year, path in files:
        cols = [f"{prefix}_005", f"{prefix}_006", "geometry"] + hist_cols + list(attr_cols.keys())
        gdf = gpd.read_file(path)
        keep_cols = [c for c in cols if c in gdf.columns]
        gdf = gdf[keep_cols]

        cat_like = set([k for k, v in attr_cols.items() if v in {"use", "structure", "city_plan"}])
        num_cols = [c for c in keep_cols if c != "geometry" and c not in cat_like]
        for c in num_cols:
            gdf[c] = pd.to_numeric(gdf[c], errors="coerce")

        def pick_price(row):
            val = row.get(f"{prefix}_006", np.nan)
            if pd.isna(val) or val == 0:
                for h in reversed(hist_cols):
                    if h not in row:
                        continue
                    hv = row[h]
                    if pd.notna(hv) and hv != 0:
                        return hv
            return val

        gdf["price"] = gdf.apply(pick_price, axis=1)
        gdf = gdf.dropna(subset=["price", f"{prefix}_005", "geometry"])
        gdf = gdf[gdf["price"] > 0]

        gdf["lat"] = gdf.geometry.y
        gdf["lon"] = gdf.geometry.x
        df_small = gdf[["lat", "lon", "price", f"{prefix}_005"] + hist_cols + list(attr_cols.keys())].copy()
        df_small = df_small.rename(columns={f"{prefix}_005": "year", **attr_cols})
        for hc in hist_cols:
            if hc in df_small:
                df_small = df_small.rename(columns={hc: f"hist_price_{hc[-3:]}"})
        all_df.append(df_small)

    result = pd.concat(all_df, ignore_index=True)
    return result


def _build_year_trees(points: pd.DataFrame) -> Dict[int, Tuple[BallTree, pd.DataFrame]]:
    trees = {}
    for year, sub in points.groupby("year"):
        coords_rad = np.radians(sub[["lat", "lon"]].values)
        tree = BallTree(coords_rad, metric="haversine")
        trees[int(year)] = (tree, sub.reset_index(drop=True))
    return trees


def _choose_year(year: int, available: List[int]) -> int:
    if year in available:
        return year
    diffs = [abs(y - year) for y in available]
    return available[int(np.argmin(diffs))]


def compute_geo_features(train: pd.DataFrame, test: pd.DataFrame, ks: Iterable[int] = (3, 5, 8, 10, 20), radii_km: Iterable[float] = (0.5, 1.0)) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Compute KNN land-price statistics for train/test using L01+L02 data.
    Returns feature DataFrames aligned to train/test index.
    """
    ARTIFACT_DIR.mkdir(exist_ok=True)
    cache_path = ARTIFACT_DIR / "features_geo_knn_v2.parquet"

    if cache_path.exists():
        cached = pd.read_parquet(cache_path)
        train_feat = cached[cached["split"] == "train"].drop(columns=["split"])
        test_feat = cached[cached["split"] == "test"].drop(columns=["split"])
        train_feat = train_feat.set_index("idx").sort_index()
        test_feat = test_feat.set_index("idx").sort_index()
        return train_feat, test_feat

    l01 = _load_land_points("L01")
    l02 = _load_land_points("L02")
    points = pd.concat([l01, l02], ignore_index=True)
    trees = _build_year_trees(points)
    available_years = sorted(trees.keys())
    max_k = max(ks)
    earth_km = 6371.0

    combined = pd.concat([train, test], keys=["train", "test"], names=["split", "idx"])
    feats = {f"geo_knn_mean_k{k}": np.full(len(combined), np.nan) for k in ks}
    feats.update({f"geo_knn_median_k{k}": np.full(len(combined), np.nan) for k in ks})
    feats.update({f"geo_knn_min_dist_km_k{k}": np.full(len(combined), np.nan) for k in ks})
    radii = list(radii_km)
    for r in radii:
        feats[f"geo_knn_count_r{r}"] = np.full(len(combined), np.nan)
        feats[f"geo_knn_mean_r{r}"] = np.full(len(combined), np.nan)
        feats[f"geo_knn_median_r{r}"] = np.full(len(combined), np.nan)
    near_cols = ["price", "use", "city_plan", "structure", "floor_above", "floor_below", "bcr", "fsr", "land_area"]
    for c in near_cols:
        arr = np.empty(len(combined), dtype=object)
        arr[:] = np.nan
        feats[f"geo_near_{c}"] = arr
    feats["geo_near_price_yoy"] = np.full(len(combined), np.nan)
    used_years = np.full(len(combined), np.nan)

    for target_year in combined["target_year"].unique():
        idx_mask = combined["target_year"] == target_year
        mask = idx_mask.to_numpy()
        coords = combined.loc[idx_mask, ["lat", "lon"]].to_numpy()
        if len(coords) == 0:
            continue
        coords_rad = np.radians(coords)

        year_use = _choose_year(int(target_year), available_years)
        tree, sub = trees[year_use]
        k_use = min(max_k, len(sub))
        if k_use == 0:
            continue
        dist, ind = tree.query(coords_rad, k=k_use)
        price_arr = sub["price"].to_numpy()
        hist_cols = [c for c in sub.columns if c.startswith("hist_price_")]

        used_years[mask] = year_use
        for k in ks:
            kk = min(k, k_use)
            if kk == 0:
                continue
            price_k = price_arr[ind[:, :kk]]
            dist_k = dist[:, :kk] * earth_km
            feats[f"geo_knn_mean_k{k}"][mask] = price_k.mean(axis=1)
            feats[f"geo_knn_median_k{k}"][mask] = np.median(price_k, axis=1)
            feats[f"geo_knn_min_dist_km_k{k}"][mask] = dist_k.min(axis=1)

        for r in radii:
            r_rad = r / earth_km
            ind_list, dist_list = tree.query_radius(coords_rad, r=r_rad, return_distance=True)
            counts = np.fromiter((len(ix) for ix in ind_list), dtype=float, count=len(ind_list))
            mean_vals = []
            med_vals = []
            for ix in ind_list:
                if len(ix) == 0:
                    mean_vals.append(np.nan)
                    med_vals.append(np.nan)
                else:
                    pvals = price_arr[ix]
                    mean_vals.append(pvals.mean())
                    med_vals.append(np.median(pvals))
            feats[f"geo_knn_count_r{r}"][mask] = counts
            feats[f"geo_knn_mean_r{r}"][mask] = np.array(mean_vals)
            feats[f"geo_knn_median_r{r}"][mask] = np.array(med_vals)

        nearest_idx = ind[:, 0]
        for c in near_cols:
            feats[f"geo_near_{c}"][mask] = sub[c].to_numpy()[nearest_idx] if c in sub else np.nan
        if hist_cols:
            hist_arr = sub[hist_cols].to_numpy()
            prev = []
            for i in nearest_idx:
                row = hist_arr[i]
                vals = row[~np.isnan(row)]
                prev.append(vals[-1] if len(vals) else np.nan)
            prev = np.array(prev, dtype=float)
            cur = price_arr[nearest_idx]
            yoy = np.where((prev > 0) & (~np.isnan(prev)), (cur - prev) / prev, np.nan)
            feats["geo_near_price_yoy"][mask] = yoy

    feat_df = pd.DataFrame(feats, index=combined.index)
    feat_df["geo_knn_year_used"] = used_years

    train_feat = feat_df.loc["train"].copy()
    test_feat = feat_df.loc["test"].copy()

    cat_near = ["geo_near_use", "geo_near_structure", "geo_near_city_plan"]
    num_near = ["geo_near_price", "geo_near_floor_above", "geo_near_floor_below", "geo_near_bcr", "geo_near_fsr", "geo_near_land_area", "geo_near_price_yoy"]
    for c in cat_near:
        if c in train_feat:
            train_feat[c] = train_feat[c].astype("string")
            test_feat[c] = test_feat[c].astype("string")
    for c in num_near:
        if c in train_feat:
            train_feat[c] = pd.to_numeric(train_feat[c], errors="coerce")
            test_feat[c] = pd.to_numeric(test_feat[c], errors="coerce")

    out_train = train_feat.reset_index().rename(columns={"idx": "idx"})
    out_test = test_feat.reset_index().rename(columns={"idx": "idx"})
    cached = pd.concat([out_train.assign(split="train"), out_test.assign(split="test")], ignore_index=True)
    cached.to_parquet(cache_path, index=False)
    return train_feat, test_feat


def _build_prefix_year_trees(points: pd.DataFrame) -> Dict[int, Tuple[BallTree, pd.DataFrame]]:
    trees = {}
    for year, sub in points.groupby("year"):
        coords_rad = np.radians(sub[["lat", "lon"]].values)
        tree = BallTree(coords_rad, metric="haversine")
        trees[int(year)] = (tree, sub.reset_index(drop=True))
    return trees


def _query_price_attrs(prefix_trees: Dict[int, Tuple[BallTree, pd.DataFrame]], target_year: int, coords_rad: np.ndarray, k: int = 5, include_attrs: bool = True):
    """
    Query nearest land points for given year. Returns dict of arrays.
    """
    if not prefix_trees:
        raise ValueError("prefix_trees is empty")
    available = sorted(prefix_trees.keys())
    year_use = _choose_year(target_year, available)
    tree, sub = prefix_trees[year_use]
    earth_km = 6371.0
    k_use = min(k, len(sub))
    dist, ind = tree.query(coords_rad, k=k_use)
    price_arr = sub["price"].to_numpy()
    result = {
        "price_near": price_arr[ind[:, 0]],
        "price_mean": price_arr[ind[:, :k_use]].mean(axis=1),
        "price_median": np.median(price_arr[ind[:, :k_use]], axis=1),
        "dist_km": dist[:, 0] * earth_km,
        "year_used": np.full(len(coords_rad), year_use),
    }
    if include_attrs:
        attr_cols = ["use", "city_plan", "structure", "bcr", "fsr", "floor_above", "floor_below", "land_area"]
        nearest_idx = ind[:, 0]
        for c in attr_cols:
            if c in sub:
                result[c] = sub[c].to_numpy()[nearest_idx]
            else:
                result[c] = np.full(len(coords_rad), np.nan, dtype=object)
    return result


def compute_land_temporal_features(train: pd.DataFrame, test: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Month-aware land price features: main (closest survey) & previous year, and yoy.
    Uses L01 (Jan) / L02 (Jul) nearest joins with year fallback. Cached to parquet.
    (Half-yearと公示属性はノイズ低減のため除外)
    """
    ARTIFACT_DIR.mkdir(exist_ok=True)
    cache_path = ARTIFACT_DIR / "features_land_temporal_v2.parquet"
    if cache_path.exists():
        cached = pd.read_parquet(cache_path)
        tr = cached[cached["split"] == "train"].drop(columns=["split"]).set_index("idx").sort_index()
        te = cached[cached["split"] == "test"].drop(columns=["split"]).set_index("idx").sort_index()
        return tr, te

    l01_points = _load_land_points("L01")
    l02_points = _load_land_points("L02")
    l01_trees = _build_prefix_year_trees(l01_points)
    l02_trees = _build_prefix_year_trees(l02_points)

    combined = pd.concat([train, test], keys=["train", "test"], names=["split", "idx"])
    n = len(combined)
    target_year = combined["target_year"].astype(int).to_numpy()
    target_month = combined["target_month"].astype(int).to_numpy()
    main_src = np.where(target_month <= 4, "L01", "L02")
    main_year = target_year
    prev_src = main_src
    prev_year = target_year - 1

    def run_queries(src_arr, year_arr):
        price = np.full(n, np.nan)
        price_mean = np.full(n, np.nan)
        price_med = np.full(n, np.nan)
        dist = np.full(n, np.nan)
        year_used = np.full(n, np.nan)

        for src, trees in [("L01", l01_trees), ("L02", l02_trees)]:
            mask = src_arr == src
            if not mask.any():
                continue
            years_unique = np.unique(year_arr[mask])
            for y in years_unique:
                sub_mask = mask & (year_arr == y)
                coords_rad = np.radians(combined.loc[sub_mask, ["lat", "lon"]].to_numpy())
                res = _query_price_attrs(trees, int(y), coords_rad, k=5, include_attrs=False)
                price[sub_mask] = res["price_near"]
                price_mean[sub_mask] = res["price_mean"]
                price_med[sub_mask] = res["price_median"]
                dist[sub_mask] = res["dist_km"]
                year_used[sub_mask] = res["year_used"]
        return price, price_mean, price_med, dist, year_used

    main_price, main_mean, main_med, main_dist, main_year_used = run_queries(main_src, main_year)
    prev_price, prev_mean, prev_med, prev_dist, prev_year_used = run_queries(prev_src, prev_year)

    yoy = np.full(n, np.nan)
    valid_prev = (prev_price > 0) & np.isfinite(prev_price)
    yoy[valid_prev] = (main_price[valid_prev] - prev_price[valid_prev]) / prev_price[valid_prev]

    feat = pd.DataFrame(
        {
            "land_main_price": main_price,
            "land_main_price_k5": main_mean,
            "land_main_price_median_k5": main_med,
            "land_main_dist_km": main_dist,
            "land_main_year_used": main_year_used,
            "land_prev_price": prev_price,
            "land_prev_price_k5": prev_mean,
            "land_prev_price_median_k5": prev_med,
            "land_prev_dist_km": prev_dist,
            "land_prev_year_used": prev_year_used,
            "land_price_yoy": yoy,
        },
        index=combined.index,
    )

    feat = feat.reset_index()
    cached = feat.copy()
    cached["split"] = cached["split"].astype(str)
    cached.to_parquet(cache_path, index=False)

    tr = feat[feat["split"] == "train"].drop(columns=["split"]).set_index("idx").sort_index()
    te = feat[feat["split"] == "test"].drop(columns=["split"]).set_index("idx").sort_index()
    return tr, te


def compute_n05_features(train: pd.DataFrame, test: pd.DataFrame, radii_km: Iterable[float] = (0.5, 1.0), include_freq: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    最近駅距離と駅数（N05 Station2）を付与する。
    - n05_station_min_dist_km: 最近駅までの距離
    - n05_station_second_dist_km: 2番目に近い駅までの距離
    - n05_station_mean_dist_k3: 上位3駅の平均距離
    - n05_station_count_{r}km: 半径r km内の駅数
    - n05_nearest_line_freq / n05_nearest_station_freq: 全駅での出現頻度
    """
    import geopandas as gpd  # noqa: WPS433

    base_dir = DATA_DIR / "N05"
    station_files = sorted(base_dir.glob("N05-*Station*.geojson"))
    freq_cols = ["n05_nearest_line_freq", "n05_nearest_station_freq"] if include_freq else []
    cols = [
        "n05_station_min_dist_km",
        "n05_station_second_dist_km",
        "n05_station_mean_dist_k3",
        *[f"n05_station_count_{r}km" for r in radii_km],
        *freq_cols,
    ]
    if not station_files:
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    station_path = station_files[-1]
    gdf = gpd.read_file(station_path)
    gdf = gdf[gdf.geometry.notnull()].copy()
    gdf["lat"] = gdf.geometry.y
    gdf["lon"] = gdf.geometry.x
    station_df = gdf[["lat", "lon", "N05_002", "N05_011"]].rename(columns={"N05_002": "line_name", "N05_011": "station_name"})
    station_df = station_df.dropna(subset=["lat", "lon"]).reset_index(drop=True)
    if station_df.empty:
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    coords_rad_station = np.radians(station_df[["lat", "lon"]].values)
    tree = BallTree(coords_rad_station, metric="haversine")
    earth_km = 6371.0

    line_freq = station_df["line_name"].value_counts(normalize=True) if include_freq else None
    st_freq = station_df["station_name"].value_counts(normalize=True) if include_freq else None

    def _build(df: pd.DataFrame) -> pd.DataFrame:
        out = pd.DataFrame(index=df.index)
        coords_rad = np.radians(df[["lat", "lon"]].values)
        dist, ind = tree.query(coords_rad, k=min(3, len(station_df)))
        dist_km = dist * earth_km
        # padding in case k<3
        if dist_km.shape[1] < 3:
            pad = np.repeat(dist_km[:, -1:], 3 - dist_km.shape[1], axis=1)
            dist_km = np.concatenate([dist_km, pad], axis=1)
            ind = np.concatenate([ind, np.repeat(ind[:, -1:], 3 - ind.shape[1], axis=1)], axis=1)

        out["n05_station_min_dist_km"] = dist_km[:, 0]
        out["n05_station_second_dist_km"] = dist_km[:, 1]
        out["n05_station_mean_dist_k3"] = dist_km.mean(axis=1)

        for r in radii_km:
            counts = tree.query_radius(coords_rad, r=r / earth_km, count_only=True)
            out[f"n05_station_count_{r}km"] = counts

        if include_freq:
            nearest_idx = ind[:, 0]
            out["n05_nearest_line_freq"] = station_df.iloc[nearest_idx]["line_name"].map(line_freq).to_numpy()
            out["n05_nearest_station_freq"] = station_df.iloc[nearest_idx]["station_name"].map(st_freq).to_numpy()
        return out

    return _build(train), _build(test)


def compute_s12_passenger_features(train: pd.DataFrame, test: pd.DataFrame, k: int = 3) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    S12 駅別乗降客数から、最寄・上位k駅の乗降客数統計を付与する。
    - s12_passenger_nearest
    - s12_passenger_mean_k{k}
    - s12_passenger_max_k{k}
    - s12_passenger_min_dist_km
    """
    import geopandas as gpd  # noqa: WPS433

    path = DATA_DIR / "S12" / "S12-24_NumberOfPassengers.geojson"
    if not path.exists():
        cols = [f"s12_passenger_{c}" for c in ["nearest", f"mean_k{k}", f"max_k{k}", "min_dist_km"]]
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    gdf = gpd.read_file(path)
    if gdf.empty:
        cols = [f"s12_passenger_{c}" for c in ["nearest", f"mean_k{k}", f"max_k{k}", "min_dist_km"]]
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    # pick representative point (geometry is line: use centroid)
    gdf = gdf[gdf.geometry.notnull()].copy()
    gdf["lat"] = gdf.geometry.centroid.y
    gdf["lon"] = gdf.geometry.centroid.x

    # pick latest available passenger column
    passenger_cols = [c for c in gdf.columns if c.startswith("S12_") and c[4:].isdigit() and int(c[4:]) >= 9]
    passenger_cols = [c for c in passenger_cols if gdf[c].dtype != object]
    passenger_cols = sorted(passenger_cols, key=lambda x: int(x.split("_")[1]))
    if not passenger_cols:
        cols = [f"s12_passenger_{c}" for c in ["nearest", f"mean_k{k}", f"max_k{k}", "min_dist_km"]]
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    # latest (max year)
    latest_col = max(passenger_cols, key=lambda x: int(x.split("_")[1]))
    gdf["passenger_latest"] = pd.to_numeric(gdf[latest_col], errors="coerce")
    gdf = gdf.dropna(subset=["lat", "lon", "passenger_latest"])
    if gdf.empty:
        cols = [f"s12_passenger_{c}" for c in ["nearest", f"mean_k{k}", f"max_k{k}", "min_dist_km"]]
        return pd.DataFrame(0, index=train.index, columns=cols), pd.DataFrame(0, index=test.index, columns=cols)

    coords_rad = np.radians(gdf[["lat", "lon"]].to_numpy())
    tree = BallTree(coords_rad, metric="haversine")
    earth_km = 6371.0
    passengers = gdf["passenger_latest"].to_numpy()

    def build(df: pd.DataFrame) -> pd.DataFrame:
        out = pd.DataFrame(index=df.index)
        coords = np.radians(df[["lat", "lon"]].to_numpy())
        dist, ind = tree.query(coords, k=min(k, len(gdf)))
        dist_km = dist * earth_km
        nearest_idx = ind[:, 0]
        out["s12_passenger_nearest"] = passengers[nearest_idx]
        out[f"s12_passenger_mean_k{k}"] = passengers[ind].mean(axis=1)
        out[f"s12_passenger_max_k{k}"] = passengers[ind].max(axis=1)
        out["s12_passenger_min_dist_km"] = dist_km[:, 0]
        return out

    return build(train), build(test)
