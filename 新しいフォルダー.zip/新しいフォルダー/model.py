import json
from datetime import datetime
from typing import List, Optional, Sequence, Tuple

import lightgbm as lgb
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from .constants import LOG_DIR, MODEL_DIR, OUTPUT_DIR, PLOT_DIR
from .utils import mape


def _build_lgbm_params(seed: int, overrides: Optional[dict] = None):
    """Default LightGBM params merged with overrides."""
    base = {
        "objective": "mae",
        "n_estimators": 800,
        "learning_rate": 0.05,
        "num_leaves": 127,
        "max_depth": 8,
        "min_child_samples": 50,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "random_state": seed,
        "n_jobs": -1,
    }
    if overrides:
        base.update(overrides)
    return base


def cv_train(
    train_df,
    y,
    cat_cols,
    n_splits=5,
    seed=42,
    price_multiplier=None,
    y_price=None,
    sample_weight=None,
    log_target=False,
    lgb_params: Optional[dict] = None,
    eval_metric: str = "l1",
):
    from sklearn.model_selection import KFold

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
    oof = np.zeros(len(train_df))
    models: List[lgb.LGBMRegressor] = []
    best_iters: List[float] = []
    for fold, (tr_idx, va_idx) in enumerate(kf.split(train_df), 1):
        print(f"Starting fold {fold}/{n_splits}...")
        X_tr, X_va = train_df.iloc[tr_idx], train_df.iloc[va_idx]
        y_tr, y_va = y.iloc[tr_idx], y.iloc[va_idx]
        sw_tr = sample_weight[tr_idx] if sample_weight is not None else None

        params = _build_lgbm_params(seed + fold, lgb_params)
        model = lgb.LGBMRegressor(**params)

        model.fit(
            X_tr,
            y_tr,
            sample_weight=sw_tr,
            eval_set=[(X_va, y_va)],
            eval_metric=eval_metric,
            categorical_feature=cat_cols,
            callbacks=[lgb.early_stopping(50, verbose=False)],
        )

        best_iters.append(model.best_iteration_)
        pred = model.predict(X_va, num_iteration=model.best_iteration_)

        if log_target:
            pred_unit = np.expm1(pred)
        else:
            pred_unit = pred

        if price_multiplier is not None and y_price is not None:
            mult_va = np.asarray(price_multiplier)[va_idx]
            pred_eval = pred_unit * mult_va
            y_eval_true = y_price.iloc[va_idx]
        else:
            pred_eval = pred_unit
            y_eval_true = y_va

        oof[va_idx] = pred_eval
        models.append(model)

        fold_mape = mape(y_eval_true, pred_eval)
        print(f"Fold {fold} MAPE: {fold_mape:.4f}")

    if price_multiplier is not None and y_price is not None:
        cv_mape = mape(y_price, oof)
    else:
        cv_mape = mape(y if not log_target else np.expm1(y), oof)
    print(f"CV MAPE: {cv_mape:.4f}")
    return models, oof, cv_mape, np.mean(best_iters)


def train_full(train_df, y, cat_cols, n_estimators, lgb_params: Optional[dict] = None):
    params = _build_lgbm_params(2024, lgb_params)
    # n_estimatorsはCVのbest_iterの平均で上書きする（最低200）
    params["n_estimators"] = int(max(n_estimators, 200))
    model = lgb.LGBMRegressor(**params)
    model.fit(train_df, y, categorical_feature=cat_cols)
    return model


def save_plots(run_name: str, y: pd.Series, oof: np.ndarray, train_df: pd.DataFrame, models: Sequence[lgb.LGBMRegressor]):
    """
    Save YY plot, residual histogram, and feature importance (png + csv).
    """
    PLOT_DIR.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(42)
    if len(y) > 20000:
        idx = rng.choice(len(y), size=20000, replace=False)
        y_plot = y.iloc[idx]
        oof_plot = oof[idx]
    else:
        y_plot = y
        oof_plot = oof

    plt.figure(figsize=(6, 6))
    plt.scatter(y_plot, oof_plot, s=3, alpha=0.3)
    lim_min = min(y_plot.min(), oof_plot.min())
    lim_max = max(y_plot.max(), oof_plot.max())
    plt.plot([lim_min, lim_max], [lim_min, lim_max], color="red", linestyle="--", linewidth=1)
    plt.xlabel("Actual money_room")
    plt.ylabel("Predicted money_room")
    plt.title("YY Plot")
    plt.tight_layout()
    yy_dir = PLOT_DIR / "yy"
    yy_dir.mkdir(parents=True, exist_ok=True)
    yy_path = yy_dir / f"yy_{run_name}.png"
    plt.savefig(yy_path, dpi=150)
    plt.close()

    residuals = y - oof
    plt.figure(figsize=(6, 4))
    plt.hist(residuals, bins=100, alpha=0.8, color="steelblue")
    plt.xlabel("Residual (y - yhat)")
    plt.ylabel("Count")
    plt.title("Residual Distribution")
    plt.tight_layout()
    res_dir = PLOT_DIR / "residual"
    res_dir.mkdir(parents=True, exist_ok=True)
    res_path = res_dir / f"residual_{run_name}.png"
    plt.savefig(res_path, dpi=150)
    plt.close()

    if models:
        importances = np.zeros(len(train_df.columns))
        for m in models:
            importances += m.feature_importances_
        importances /= len(models)
        fi_df = pd.DataFrame({"feature": train_df.columns, "importance": importances})
        fi_df = fi_df.sort_values("importance", ascending=False)
        fi_dir = PLOT_DIR / "feature_importance"
        fi_dir.mkdir(parents=True, exist_ok=True)
        fi_csv = fi_dir / f"feature_importance_{run_name}.csv"
        fi_df.to_csv(fi_csv, index=False)

        topk = fi_df.head(30)
        plt.figure(figsize=(8, 8))
        plt.barh(topk["feature"], topk["importance"])
        plt.gca().invert_yaxis()
        plt.title("Feature Importance (top 30)")
        plt.tight_layout()
        fi_png = fi_dir / f"feature_importance_{run_name}.png"
        plt.savefig(fi_png, dpi=150)
        plt.close()

    print(f"Saved plots to {PLOT_DIR} (yy, residual, feature importance)")


def save_logs(run_name, cv_mape, best_iter, feature_set=None, extra: Optional[dict] = None):
    LOG_DIR.mkdir(exist_ok=True)
    json_dir = LOG_DIR / "json"
    json_dir.mkdir(exist_ok=True)
    record = {
        "run_name": run_name,
        "cv_mape": float(cv_mape),
        "best_iter": float(best_iter),
        "timestamp": datetime.now().isoformat(),
        "feature_set": feature_set,
    }
    if extra:
        record.update(extra)
    with open(json_dir / f"{run_name}.json", "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2, ensure_ascii=False)

    hist_path = LOG_DIR / "score_history.csv"
    header_needed = not hist_path.exists()
    with open(hist_path, "a", encoding="utf-8") as f:
        if header_needed:
            f.write("run_name,cv_mape,best_iter,feature_set,timestamp\n")
        f.write(f"{run_name},{cv_mape},{best_iter},{feature_set or ''},{record['timestamp']}\n")
