プロジェクトノート
==================

目的
----
- 提供されたtrain/testと国土数値情報データ（地価公示ほか）を用いて`money_room`を予測し、MAPEを最小化する。
- 提出形式は`output/submit_LGB.csv`に準拠。

評価・管理
----------
- 指標: MAPE = (100/n) * SUM(|y - yhat| / |y|)。
- CVでMAPEを計測し、`logs/json/{run}.json`（個別ログ）と`logs/score_history.csv`（履歴）に毎回記録。
- 成果物: `output/submit_{run}.csv`
- 特徴キャッシュは`artifacts/`。
- （モデル保存は未実装。必要なら`models/`に手動保存）

データ配置
----------
- ベースデータ:
  - `input/train.csv`, `input/test.csv`（計149列: 数値105, object 44）
  - 目的変数 `money_room` は train のみ。
  - 位置: `lat`, `lon`, 
  - 基準日:`target_ym`（yyyymm）
  - 建物属性: `building_structure`, `building_type`, `floor_plan_code`, `room_count`, `total_floor_area`, `house_area` など
  - 立地ID: `addr1_1`（都道府県コード）, `addr1_2`（市区町村コード）, `N03_007`（行政区画コード）
- 国土数値情報
  - 地価（公示1月=L01 / 調査7月=L02）: `input/L01/*.geojson`, `input/L02/*.geojson`（CRS=EPSG:4612, POINT）
    - 主カラム: 年度=`L0x_005`、現行価格=`L0x_006`、履歴=`L01_056-069` / `L02_057-069`
  - 行政界: `input/N03/N03-*.geojson`（住所コード付与用）
  - 鉄道: `input/N05/N05-24_Station2.geojson`, `N05-24_Section2.geojson`（最近駅距離・路線名freqなど）
  - その他: `S12`（駅別乗降客数など、現状は精度悪化のため不採用）
- メタ/生成物
  - メタ: `input/data_definition.xlsx`（項目定義など）

ディレクトリと使い分け
----------------------
- `src/` 学習・推論コード。入口: `python -m src.train`（軽量ラッパー `src/train_baseline.py` も維持）
  - `data.py` 前処理・基本特徴
  - `features_geo.py` 公示KNN・temporal特徴
  - `features_admin.py` 行政区域付与
  - `model.py` LightGBM学習・CV・プロット・ログ
  - `constants.py` パス/基本定数
  - `utils.py` 小物
- 設定・スクリプト: **現在未使用（将来の設定管理・バッチ用に残置）**
  - `configs/` 必要になれば実験設定（特徴セット名、LGBMパラメータ、seed等）をyaml/jsonで管理。
  - `scripts/` 必要になれば `run_train.ps1` などのラッパーを配置。
- 作業ノート: `notebooks/`（EDAや試行。採用内容は`src/`や`configs/`に反映）
- 中間生成物: `artifacts/`（近傍特徴などのキャッシュ。再利用時はバージョン管理）
- ログ: `logs/score_history.csv`（履歴）, `logs/json/{run}.json`（個別ログ）
- モデル: `models/`（自動保存なし。必要なら手動保存）
- 提出物・可視化
  - 提出: `output/submit_{run}.csv`
  - 可視化・分析: `output/plots/`配下に保存
    - 特徴量重要度: `feature_importance/{run}.csv/png`
    - OOFプロット: `yy/yy_{run}.png`（OOF vs 実測）
    - 残差プロット: `residual/residual_{run}.png`
    - CV推移など: `metrics/huber_n_vs_cv.png`

前処理の要点
------------
- 時間・築年
  - `target_ym`をyear/monthに分解。
  - `building_age`をyyyymm→year抽出で算出し、0～80にクリップ。
- 列削減・型
  - 低寄与だった`reform_place`/`reform_common_area`/`reform_exterior_other`/`reform_etc`を事前drop。
  - 高カード文字列（`building_name`系、`full_address`等）をdrop。
  - 文字列は"missing"埋め。カテゴリ判定はtrain/testがobjectの列＋強制カテゴリ列（`building_status`/`bukken_type`/`traffic_car`/`addr1_1`/`addr1_2`/`land_youto`/`land_road_cond`/`land_chisei`/`building_structure`/`management_form`/`parking_kubun`/`floor_plan_code`等）。
- 数値補完・長尾処理
  - 数値は中央値埋め。非負・歪度大の列は分位クリップ(0.5～99.5%)＋`_log1p`派生。緯度経度/コード/年月/距離/`geo_knn`系は除外。
- 距離・面積クリップ
  - 距離上限: `bank_distance`/`convenience_distance`/`drugstore_distance`/`est_other_distance`/`hospital_distance`/`park_distance`/`super_distance`/`shopping_street_distance`/`school_ele_distance`/`school_jun_distance`=4000m, `parking_distance`=100m, `walk_distance1`=8000m, `walk_distance2`=6000m。
  - 面積上限: `building_area`<=10000, `total_floor_area`<=500, `building_land_area`<=2500, `land_area_all`<=2500, `snapshot_land_area`<=2000, `area_per_room`<=120000, `balcony_area`<=35, `house_area`/`unit_area`<=300。
- 欠損フラグ
  - 欠損率0.3～0.999の列に`*_isnull`を付与。
- 高カード圧縮
  - 方針: 出現上位のみ残し、それ以外は`other`にまとめる＋出現頻度の数値列（freq）を追加。基準は`coverage=0.75`（累積75%まで残す）かつ`max_top=15`（最大15カテゴリ）。
  - freq専用（カテゴリ本体はdropし、freqのみ残す）: `statuses`/`unit_tag_id`/`building_tag_id`/`addr2_name`/`addr3_name`/`eki_name{1,2,3}`/`empty_contents`/`school_ele_name`/`school_jun_name`/`est_other_name`/`unit_name`。
- 位置・エンコード
  - 緯度経度のsin/cos、kmeansクラスタ(k=20)を追加。
  - グリッドTE: lat/lonを0.01刻み、5foldでmean/median (`grid_mean_cv`/`grid_median_cv`)。
  - コード列TE: addr1_1/addr1_2/building_structure/bukken_type/floor_plan_codeに5fold mean/median（平滑化あり）。

地価KNN特徴 (geo_knn_v2)
-------------------------
- L01/L02を年度ごとに整形（`_006`優先、ゼロ/欠損は履歴の最後の非ゼロで補完）。保持カラム: year, price, lat/lon, 用途(`use`), 都市計画(`city_plan`), 構造(`structure`), `floor_above`, `floor_below`, `bcr`, `fsr`, `land_area`。
- 年度ごとにBallTree(haversine)を作成し、`target_year`に最も近い年度でクエリ。
  - K=3/5/8/10/20で価格の平均/中央値、最小距離(km)を付与 (`geo_knn_mean_k*`, `geo_knn_median_k*`, `geo_knn_min_dist_km_k*`)。
  - 半径r=0.5/1.0km内の件数/平均/中央値を付与 (`geo_knn_count_r*`, `geo_knn_mean_r*`, `geo_knn_median_r*`)。
  - 最近傍の属性を付与: `geo_near_{price,use,city_plan,structure,floor_above,floor_below,bcr,fsr,land_area}`, さらに履歴から算出した`geo_near_price_yoy`と`geo_knn_year_used`。
- キャッシュ: `artifacts/features_geo_knn_v2.parquet`（train/test連結で保存し、再利用）。

土地価格の月別特徴 (temporal v2)
---------------------------------
- データ: L01(1月)/L02(7月)の最近傍5件から、主指標（当年）と前年の平均/中央値＋距離を取得。`target_month`に応じてL01/L02を使い分け。
- 指標: `land_price_yoy`（前年比）を計算。半期・属性はノイズのため除外。
- 価格系はlog1p派生を付与。キャッシュ: `artifacts/features_land_temporal_v2.parquet`。

N05鉄道特徴
-----------
- データ: `input/N05/N05-24_Station2.geojson`（最新年のStation/Section）
- 距離系: 最近駅・2番目・上位3駅の平均距離、半径0.5/1km内の駅数を付与。
- 名称系: 最近駅の路線名/駅名の全体freqを数値で付与（カテゴリ列は増やさない）。

学習デフォルト
--------------
- CV: 5fold固定。
- `--lgb-profile`でパラメータプリセットを切替（特徴は不変）。
  - `base`: lr=0.05, n_estimators=800（early_stopping=50でbest_iter取得）。full fitはbest_iterを使用（最低200）。
  - `fast_huber`（デフォルトのスクリーニング用）: lr=0.08, n_estimators=400, objective=huber(alpha=0.9)（CV MAPE ~14.26, 所要 ~4分）。
  - `fast`: lr=0.08, n_estimators=400（速度優先; CV MAPE ~15.26, 所要 ~3分52秒）。
  - 推奨: Huber lr=0.03 で木本数を増やすとCVが改善（n=50000でCV=11.97、所要~1h23m）。精度重視ならHuber＋大きめn、速度重視ならfast_huber/fast。
  - その他プリセット（実行済み/未実行混在）: `reg_soft`（正則化強め）、`big_leaf`、`reg_strong`、`colsub_strong`、`huber`（alpha=0.9）、`mape_eval`（MAPE early stop）など。
- run_nameは`YYYYMMDD_HHMMSS_geo_knn_v1`形式で自動付与。
- 単価学習＋log1p: `money_room/house_area`に`log1p`を取り学習、予測を`expm1`戻し×`house_area`で金額化（MAPEを意識）。

現状ベスト/履歴
----------------
- ベスト: `20251215_172106_geo_knn_v1`（Huber, lr=0.03/n_estimators=50000, alpha=0.9）CV MAPE=11.9720（best_iter≈21495）。
- 次点: `20251215_155203_geo_knn_v1`（Huber, lr=0.03/n_estimators≈20000, alpha=0.9）CV MAPE=11.9858。
- 参考: `20251215_145312_geo_knn_v1`（Huber, lr=0.03/n_estimators≈15000, alpha=0.9）CV MAPE=12.0525。
- ベースライン（fast_huber）: lr=0.08/n=400, CV MAPE ≈14.26（スクリーニング用）。
- 備考: Huber(alpha=0.9)で木本数を増やすとCV改善し、n=50000で最良（所要~1h23m）。サンプリング強化/弱化・lr=0.025系の利得は小さく、fast_huberでの前処理検証→精度重視はHuber lr=0.03 大きめnが現行の方針。

出力する可視化
--------------
- YYプロット: `output/plots/yy/yy_{run}.png`（OOF vs 実測、最大2万点をサンプル）。
- 残差ヒストグラム: `output/plots/residual/residual_{run}.png`。
- 特徴量重要度: `output/plots/feature_importance/feature_importance_{run}.csv/png`。
- メトリクス推移: `output/plots/metrics/huber_n_vs_cv.png`（n_estimatorsとCVの関係）。

有効だった改善
----------------------------------
- 目的関数: Huber (alpha=0.9) を採用するとMAEよりCVが改善。
- 学習率・木数: lr=0.03でn_estimatorsを増やすほどCV改善（n=50000でCV≈11.97）。
- 高カード頻度圧縮: coverage=0.75/max_top=15＋freq付与、freq専用化（addr系/駅名/タグ等）でCV改善。
- 距離・面積の固定クリップ: 距離上限（4000/100/8000/6000）、面積上限（10000/500/2500/2500/2000/120000/35/300）で外れ値影響を緩和。
- 地価KNN (geo_knn_v2): L01/L02を統合しKNN＋半径集計＋最近傍属性/YoY付与でCV向上。
- 公示temporal v2: 取引月に応じてL01/L02を使い分け、当年＋前年価格からYoY算出（log1p派生含む）でCV向上。

今後のメモ・注意点
------------------
- CVとLBの乖離が出る可能性があるため、極大n（>2万〜5万）を使う場合はLB確認を推奨。
- 追加で試すなら: lrをわずかに下げてn増し（0.028〜0.025）、正則化を少し強める（lambdaやnum_leaves/min_child_samples調整）など小刻みに。
- 公示temporalの軽量化やgeo距離系の整理は未検証。必要に応じて検討。
- S12駅別乗降客数は効果がなく不採用のまま。
