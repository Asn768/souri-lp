from pathlib import Path

# Paths
DATA_DIR = Path("input")
OUTPUT_DIR = Path("output")
LOG_DIR = Path("logs")
MODEL_DIR = Path("models")
ARTIFACT_DIR = Path("artifacts")
PLOT_DIR = OUTPUT_DIR / "plots"

# Columns
TARGET = "money_room"
ID_COL = "id"
